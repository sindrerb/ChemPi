#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <unistd.h>
#include <RF24/RF24.h>

using namespace std;

RF24 radio(22,0);

const uint8_t pipes[][6] = {"1Node","2Node"}; 

FILE * fp;
unsigned long nowTime;
unsigned long startTime;
int sensors [10] = {};
int n = 0;

// DATA STRUCTURES
struct callStruct{
	char Call;
}message, reply;

struct dataStruct{
	float value;
	char ID;
}myData;

bool timeout(unsigned int stopTime,char sensor,bool setup){
	radio.startListening();
	unsigned long started_waiting_at = millis();
	bool timeout = false;
	bool response = false;
	while ( !response && ! timeout ) {
		if (radio.available()){
			if(setup){
			    radio.read(&reply,sizeof(reply));
			    cout << reply.Call << "\n";
			    if (reply.Call==message.Call){
		 	        response = true;
		  	    }else{
			    	printf("Failed to connect sensor %c \n Try resetting the sensor. \n",sensor);
			    }
			}else{
			    radio.read(&myData,sizeof(myData));
			    if (myData.ID==sensor){
				response = true;
			    }
			}
		}
		if (millis() - started_waiting_at > stopTime){
		timeout = true;
		}
	}
	radio.stopListening();
	return timeout;
}

bool callSensor(char sensor){
	radio.stopListening();
	message.Call = sensor;
      	radio.write( &message, sizeof(message) );
      	      	
        if(timeout(200,sensor,1)){      	
      	    printf("Timed out! \n");
      	    return false;
      	}else{
      	    return true;
      	}
      		
}

bool Read(char sensor){
	message.Call = sensor;
	radio.stopListening();
	radio.write(&message,sizeof(message));
	if(!timeout(200,sensor,0)){
		nowTime = millis();
		//radio.read(&myData,sizeof(myData));
		return true;
	}else{
		nowTime = millis();
		return false;
	}
}
float Time(){
	return (nowTime-startTime)/1E3;
}

int writeSensor(float data, float time){
	fp = fopen("testData.txt","a");	
	fprintf(fp,"%.1f \t %.2f",time,data);
  	fclose(fp);
  	return 0;
}

int main(int argc, char** argv){
  //Radio setup
  radio.begin();
  radio.setRetries(15,15);
  //radio.printDetails();

  //
  radio.openWritingPipe(pipes[0]);
  radio.openReadingPipe(1,pipes[1]);
  //radio.openReadingPipe(2,pipes[2]);
  
  //User configuration
  printf("\n Welcome to ChemPi\n");
  string input = "";
  cout << "Connect your Raspberry Pi to modules.  (CTRL+C to exit)\n";
  cout << "Enter the capital letter of a module in use, like 'A' or 'B' \n"; 
  cout << "Type 'e' to finish connecting and 'h' for more information. \n"; 
  bool endInput = 0;
  printf("Type:");
  while(endInput == 0){
    getline(cin,input);
    if(input[0]=='h'){
        cout << "Helping information: \n"; 
    }else if(input[0] == 'e'){
        cout << "Starting measurements \n \n";
        endInput = 1;
    }else if(input.length()==1){
	if(callSensor(input[0])){
	    sensors[n] = input[0];
	    n += 1;
	}
    }else{
        cout << "Invalid input \n \n";
    }
    if(!endInput){
    printf("Type:");
    }
  }
  
  fp = fopen("testData.txt","w+");
  for(int i=0;i<n;i++){
  	fprintf(fp,"Sensor %c \t ",sensors[i]);
  }  
  fprintf(fp,"\r\n");
  for(int i=0;i<n;i++){
  	fprintf(fp,"Time: \t Val:");
  	if(i!=n-1){
  		fprintf(fp,"\t");
  	}
  }
  fprintf(fp,"\r\n");
  fclose(fp);
  
  startTime = millis();
  while (true){
	int i = 0;
	while(i<n){
		if(Read(sensors[i])){
		writeSensor(myData.value,Time());
		printf("ID: %c   Value: %f   Tid: %f \n",myData.ID,myData.value,Time());
		}else{
		writeSensor(0.0,Time());
		printf("No data from %c at %f, writing 0\n",sensors[i],Time());
		}
		if(i!=n-1){
			fp = fopen("testData.txt","a");	
			fprintf(fp,"\t");
  			fclose(fp);
		}		
		i++;
	}
	
	fp = fopen("testData.txt","a");	
	fprintf(fp,"\r\n");
  	fclose(fp);
	
	i = 0;
	delay(500);	
  } // forever loop
  fclose(fp);
  return 0;
}//main

